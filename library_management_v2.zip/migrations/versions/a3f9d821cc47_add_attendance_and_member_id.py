"""add attendance table and member_id to daily_seat_bookings

Revision ID: a3f9d821cc47
Revises: 1666d0a980b9
Create Date: 2026-06-19 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = 'a3f9d821cc47'
down_revision = '1666d0a980b9'
branch_labels = None
depends_on = None


def upgrade():
    # 1. Create attendance table
    op.create_table(
        'attendance',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('member_id', sa.Integer(), nullable=False),
        sa.Column('attendance_date', sa.Date(), nullable=False),
        sa.Column('login_time', sa.DateTime(), nullable=True),
        sa.Column('logout_time', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['member_id'], ['members.id']),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('member_id', 'attendance_date', name='uq_member_per_day'),
    )

    # 2. Add member_id column to daily_seat_bookings
    # SQLite doesn't support NOT NULL without a default on existing tables,
    # so we add it as nullable first, then it stays nullable (which is fine
    # since old rows from before this migration won't exist in prod yet).
    with op.batch_alter_table('daily_seat_bookings') as batch_op:
        batch_op.add_column(
            sa.Column('member_id', sa.Integer(), sa.ForeignKey('members.id'), nullable=True)
        )


def downgrade():
    with op.batch_alter_table('daily_seat_bookings') as batch_op:
        batch_op.drop_column('member_id')

    op.drop_table('attendance')

from datetime import date

from application import db
from models import DailySeatBooking

SEATS_PER_COLUMN = 19
TOTAL_COLUMNS = 4
TOTAL_SEATS = SEATS_PER_COLUMN * TOTAL_COLUMNS  # 76

# Column 1-2 = Boys, Column 3-4 = Girls
BOYS_COLUMNS = (1, 2)
GIRLS_COLUMNS = (3, 4)


def seat_column(seat_number):
    """Return which column (1-4) a seat number belongs to."""
    return ((seat_number - 1) // SEATS_PER_COLUMN) + 1


def seat_section(seat_number):
    """Return 'Boys' or 'Girls' for a given seat number."""
    column = seat_column(seat_number)
    return "Boys" if column in BOYS_COLUMNS else "Girls"


def build_seat_layout(booking_date=None):
    """Build the full 4-column seat grid for a given day (defaults to today).

    Returns a dict keyed by column number (1-4), each holding a list of
    seat dicts: {seat_number, section, status, member_name, booking_id}.
    """
    booking_date = booking_date or date.today()

    todays_bookings = DailySeatBooking.query.filter_by(booking_date=booking_date).all()
    booked_by_seat = {b.seat_number: b for b in todays_bookings}

    columns = {col: [] for col in range(1, TOTAL_COLUMNS + 1)}
    for seat_number in range(1, TOTAL_SEATS + 1):
        column = seat_column(seat_number)
        booking = booked_by_seat.get(seat_number)
        columns[column].append(
            {
                "seat_number": seat_number,
                "section": seat_section(seat_number),
                "status": "Booked" if booking else "Available",
                "member_name": booking.member_name if booking else None,
                "booking_id": booking.id if booking else None,
            }
        )
    return columns


def book_seat_for_today(seat_number, member_name, booked_by_user_id=None):
    """Book a seat for today. Returns (booking, error_message)."""
    if not (1 <= seat_number <= TOTAL_SEATS):
        return None, f"Seat number must be between 1 and {TOTAL_SEATS}."

    member_name = (member_name or "").strip()
    if not member_name:
        return None, "Member name is required."

    today = date.today()
    existing = DailySeatBooking.query.filter_by(
        seat_number=seat_number, booking_date=today
    ).first()
    if existing:
        return None, f"Seat {seat_number} is already booked today by {existing.member_name}."

    booking = DailySeatBooking(
        seat_number=seat_number,
        member_name=member_name,
        booking_date=today,
        booked_by_user_id=booked_by_user_id,
    )
    db.session.add(booking)
    db.session.commit()
    return booking, None


def unbook_seat_for_today(seat_number):
    """Unbook a seat for today. Returns (success, error_message)."""
    today = date.today()
    existing = DailySeatBooking.query.filter_by(
        seat_number=seat_number, booking_date=today
    ).first()
    if not existing:
        return False, f"Seat {seat_number} is not currently booked today."

    db.session.delete(existing)
    db.session.commit()
    return True, None


def cleanup_past_bookings():
    """Remove booking rows from previous days so the table doesn't grow forever.

    Not strictly required for correctness (the dashboard only ever looks at
    today's date), but keeps the table tidy over time.
    """
    today = date.today()
    DailySeatBooking.query.filter(DailySeatBooking.booking_date < today).delete()
    db.session.commit()

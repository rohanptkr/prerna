from datetime import datetime, date
from application import db


class DailySeatBooking(db.Model):
    """A walk-in, name-only booking for a single seat on a single day.

    Unlike `Booking` (which ties a registered Member to a seat for a
    multi-day membership period), this is a lightweight daily record:
    pick a seat number, type a name, and it's booked just for today.
    Rows are scoped by `booking_date`, so a new day naturally starts
    with an empty board without needing any seat/status to be reset.
    """

    __tablename__ = "daily_seat_bookings"
    __table_args__ = (
        db.UniqueConstraint("seat_number", "booking_date", name="uq_seat_per_day"),
    )

    id = db.Column(db.Integer, primary_key=True)
    seat_number = db.Column(db.Integer, nullable=False)
    member_name = db.Column(db.String(120), nullable=False)
    booking_date = db.Column(db.Date, default=date.today, nullable=False)
    booked_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    booked_by = db.relationship("User")

    def __repr__(self):
        return f"<DailySeatBooking seat={self.seat_number} date={self.booking_date}>"

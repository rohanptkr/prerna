document.addEventListener("DOMContentLoaded", function () {
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
  const alertArea = document.getElementById("daily-seats-alert-area");

  const bookModalEl = document.getElementById("bookSeatModal");
  const unbookModalEl = document.getElementById("unbookSeatModal");
  if (!bookModalEl || !unbookModalEl) return; // not on this page

  const bookModal = new bootstrap.Modal(bookModalEl);
  const unbookModal = new bootstrap.Modal(unbookModalEl);

  const memberNameInput = document.getElementById("memberNameInput");
  const bookSeatError = document.getElementById("bookSeatError");
  const confirmBookBtn = document.getElementById("confirmBookBtn");
  const bookSeatNumberLabel = document.getElementById("bookSeatNumberLabel");

  const unbookSeatNumberLabel = document.getElementById("unbookSeatNumberLabel");
  const unbookSeatNumberText = document.getElementById("unbookSeatNumberText");
  const unbookMemberNameText = document.getElementById("unbookMemberNameText");
  const unbookSeatError = document.getElementById("unbookSeatError");
  const confirmUnbookBtn = document.getElementById("confirmUnbookBtn");

  let activeSeatNumber = null;
  let activeSeatBtn = null;

  function showPageAlert(message, category) {
    if (!alertArea) return;
    const wrapper = document.createElement("div");
    wrapper.className = `alert alert-${category} alert-dismissible fade show`;
    wrapper.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    alertArea.appendChild(wrapper);
    setTimeout(() => wrapper.remove(), 4000);
  }

  function setSeatBooked(button, seatNumber, memberName) {
    button.classList.remove("available");
    button.classList.add("booked");
    button.dataset.status = "Booked";
    button.dataset.memberName = memberName;
    button.innerHTML = `${seatNumber}<span class="seat-name">${escapeHtml(memberName)}</span>`;
  }

  function setSeatAvailable(button, seatNumber) {
    button.classList.remove("booked");
    button.classList.add("available");
    button.dataset.status = "Available";
    button.dataset.memberName = "";
    button.innerHTML = `${seatNumber}`;
  }

  function escapeHtml(value) {
    const div = document.createElement("div");
    div.textContent = value;
    return div.innerHTML;
  }

  document.querySelectorAll(".seat-btn").forEach((button) => {
    button.addEventListener("click", function () {
      activeSeatNumber = parseInt(button.dataset.seatNumber, 10);
      activeSeatBtn = button;

      if (button.dataset.status === "Available") {
        memberNameInput.value = "";
        bookSeatError.style.display = "none";
        bookSeatNumberLabel.textContent = `#${activeSeatNumber}`;
        bookModal.show();
        setTimeout(() => memberNameInput.focus(), 300);
      } else {
        unbookSeatError.style.display = "none";
        unbookSeatNumberLabel.textContent = `#${activeSeatNumber}`;
        unbookSeatNumberText.textContent = `#${activeSeatNumber}`;
        unbookMemberNameText.textContent = button.dataset.memberName || "—";
        unbookModal.show();
      }
    });
  });

  confirmBookBtn.addEventListener("click", function () {
    const memberName = memberNameInput.value.trim();
    if (!memberName) {
      bookSeatError.textContent = "Please enter a member name.";
      bookSeatError.style.display = "block";
      return;
    }

    confirmBookBtn.disabled = true;
    fetch("/daily-seats/book", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrfToken,
      },
      body: JSON.stringify({ seat_number: activeSeatNumber, member_name: memberName }),
    })
      .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
      .then(({ ok, data }) => {
        confirmBookBtn.disabled = false;
        if (!ok || !data.success) {
          bookSeatError.textContent = data.message || "Could not book this seat.";
          bookSeatError.style.display = "block";
          return;
        }
        setSeatBooked(activeSeatBtn, activeSeatNumber, data.member_name);
        bookModal.hide();
        showPageAlert(`Seat #${activeSeatNumber} booked for ${escapeHtml(data.member_name)}.`, "success");
      })
      .catch(() => {
        confirmBookBtn.disabled = false;
        bookSeatError.textContent = "Something went wrong. Please try again.";
        bookSeatError.style.display = "block";
      });
  });

  confirmUnbookBtn.addEventListener("click", function () {
    confirmUnbookBtn.disabled = true;
    fetch("/daily-seats/unbook", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrfToken,
      },
      body: JSON.stringify({ seat_number: activeSeatNumber }),
    })
      .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
      .then(({ ok, data }) => {
        confirmUnbookBtn.disabled = false;
        if (!ok || !data.success) {
          unbookSeatError.textContent = data.message || "Could not unbook this seat.";
          unbookSeatError.style.display = "block";
          return;
        }
        setSeatAvailable(activeSeatBtn, activeSeatNumber);
        unbookModal.hide();
        showPageAlert(`Seat #${activeSeatNumber} is now available.`, "success");
      })
      .catch(() => {
        confirmUnbookBtn.disabled = false;
        unbookSeatError.textContent = "Something went wrong. Please try again.";
        unbookSeatError.style.display = "block";
      });
  });

  // Allow pressing Enter in the name field to confirm booking
  memberNameInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      confirmBookBtn.click();
    }
  });
});
